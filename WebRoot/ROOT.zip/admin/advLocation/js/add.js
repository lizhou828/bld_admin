$(function(){
    $(document).ready(function(){
        if($("#isSucc").val()!=''){
            alert($("#isSucc").val());
        }
    });



}) ;

