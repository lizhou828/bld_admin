$(document).ready(function(){
	if($('#succes').val()!=''){
		alert($('#succes').val());
	}
	$.ajax({type:'POST',
		   url:$('#path').val()+'admin/shop/goods_main.action',
		   data:'',
		   success:function(date){
			   var gcArray=eval(date);
			   for(i=0;i<gcArray.length;i++){
				   var op='<option value="'+gcArray[i].id+'">'+gcArray[i].name+'</option>';
				   $('#gSrot').append(op);
				   }
			   }
		   })
	$('#gcsrot').hide();
	$("#ts").show();
});

$(function(){ 
	$(":radio").click(function(){
		var value=$(":radio:checked").val();
		if(value==0){
			$("#zl").hide(10);
			$("#gPw").val(0);
		}else if(value==1){
			$("#zl").show(10);
		}
	});
	$('#gSrot').change(function(){
		$('#gcsrot').children().remove("option[value]");
		if($('#gSrot').val()==' '){
			 $('#gcsrot').hide();
			 $("#ts").show();
			return;
			}
		$.ajax({type:'POST',
		   url:$('#path').val()+'admin/shop/goods_main!showSubtype.action',
		   data:'gSortId='+$('#gSrot').val(),
		   success:function(date){
			   var gcArray=eval(date);
			   if(gcArray.length==0){
				 $('#gcsrot').hide();
				 $("#ts").show();
				   return ;
				}
			   for(i=0;i<gcArray.length;i++){
				   var op='<option value="'+gcArray[i].id+'">'+gcArray[i].name+'</option>';
				   $('#gcsrot').append(op);
				   }
				  $('#gcsrot').show();
				  $("#ts").hide();
			   }
		   })													
		});
	
	$("#gPds").keyup(function(){
		var num=$(this).val().length;
		//alert(num);
			if(num<=128){
				$("#gPdsNum").html("还可以输入"+(128-num)+"个字符. ")	;
			}else{
				$("#gPdsNum").html("页面描叙内容过长!");
			}
		});
	
	$('#tjBut').click(function(){
		var gSrot=$("#gSrot").val();//类型
        alert("gSrot="+gSrot+",type="+typeof gSrot);
        var gcsrot = $("#gcsrot").val();
        alert("gcsrot="+gcsrot+",type="+typeof gcsrot);
		//alert($("#gcsrot").val());
		if(gSrot==' '||gSrot==null){
			alert("商品类型不能为空!请选择..。。。。。");
			return ;
		}

//        if(typeof gcsrot )
		var gSn=$("#gSn").val();//货号
		if(gSn==''){
			alert("货号不能为空!");
			return ;
		}
		if(gSn.length>=128){
			alert("货号的长度太长!");
		}
		var goodsName=$("#goodsName").val();//名称
		if(goodsName==''){
			alert("商品名称不能为空!");
			return ;
		}
		var gMp=$("#gMp").val();//价格
		if(gMp==''){
			alert("价格不能为空!");
			return ;
		}
		if(isNaN(gMp)){
			alert("请输入数字!");
			return ;
		}
		var gPd=$("#gPd").val();//市场价格
		if(gPd==''){
			alert("市场价格不能为空!");
			return ;
		}
		if(isNaN(gPd)){
			alert("请输入数字!");
			return;
		}
		var gPw=$("#gPw").val();//重量
		if(gPw==''){
			alert("重量不能为空!");
			return ;
		}
		if(isNaN(gPw)){
			alert("请输入数字!");
			return;
		}
		var gSk=$("#gSk").val();//库存数量
		if(gSk==''){
			alert("库存数量不能为空!");
			return ;
		}
		if(isNaN(gSk)){
			alert("请输入数字!");
			return;
		}
		if($("#gPds").val().length>128){
			alert("页面描叙内容过长!");
			return ;
		}
		var gOs=$("#gOs").val();//新旧程度
		if(gOs==''){
			alert("输入值不能为空!");
			return;
			}
		var gpH=$("#gpH").val();//图片路径
		 //验证上传文件类型
		var allowFileType = "JPG,PNG,GIF";
		if(!checkFileType(gpH, allowFileType)){
			alert("请输入'jpg,png,gif'格式的图片!");
			return ;
		};
		$("#form_gAdd").submit();
	});
	
})